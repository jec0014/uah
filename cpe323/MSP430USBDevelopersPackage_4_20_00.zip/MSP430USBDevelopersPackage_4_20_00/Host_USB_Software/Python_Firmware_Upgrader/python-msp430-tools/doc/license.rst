=========
 License
=========

This is the simplified BSD license.

.. literalinclude:: ../LICENSE.txt
