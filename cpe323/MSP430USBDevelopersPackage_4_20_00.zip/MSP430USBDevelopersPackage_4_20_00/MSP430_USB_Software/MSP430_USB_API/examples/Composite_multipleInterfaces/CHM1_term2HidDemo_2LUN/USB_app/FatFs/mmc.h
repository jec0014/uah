/* --COPYRIGHT--,NULL
 **
 * --/COPYRIGHT--*/
uint8_t detectCard (void);
//Released_Version_4_20_00
